
const dlt=()=>{
    let x=document.querySelector("#o");
        x.value="";
    }
    
    //mot de passe 
    
    
    
    const a=()=>{
        let x=document.querySelector("#o");
        x.value+="0";
    }
    
    const b=()=>{
        let x=document.querySelector("#o");
        x.value+="1";
    }
    
    const c=()=>{
        let x=document.querySelector("#o");
        x.value+="2";
    }
    
    const d=()=>{
        let x=document.querySelector("#o");
        x.value+="3";
    }
    
    const e=()=>{
        let x=document.querySelector("#o");
        x.value+="4";
    }
    
    const f=()=>{
        let x=document.querySelector("#o");
        x.value+="5";
    }
    
    const g=()=>{
        let x=document.querySelector("#o");
        x.value+="6";
    }
    
    const h=()=>{
        let x=document.querySelector("#o");
        x.value+="7";
    }
    
    const z=()=>{
        let x=document.querySelector("#o");
        x.value+="8";
    }
    
    const j=()=>{
        let x=document.querySelector("#o");
        x.value+="9";
    }
    
    
    const alert3=()=>{
    swal({
      title: "erreur",
      text: "identifiants ou code incorrect",
      icon: "error",
      dangerMode: true,
    })}