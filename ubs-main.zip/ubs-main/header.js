document.write('<div class="navbar"><img src="img/ing.jpg" alt="logo_banque" /></div>')
